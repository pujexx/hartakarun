<?php

echo "Selamat Datang Mas Mbak admin : " . $this->session->userdata('nama_admin');
?>
