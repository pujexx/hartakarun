
<?php echo $headerjs; ?>
<?php echo $headerpeta; ?>
<div>
<?php echo $onload; ?>
<?php echo $peta; ?>
</div>