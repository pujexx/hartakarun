<?php
echo "Selamat datang : " .$this->session->userdata('nama');

?>
<script type="text/javascript">
    function bikinstatus(){
       $(document).ready(function(){
          status= $("#status").val();
           $(".statusitem1").before(' <div class="statusitem">'+status+'</div>');
       });
    }
</script>
<br>
<textarea cols="80" rows="4" id="status"></textarea>
<br>
<input type="button" value="Post" id="post" onclick="bikinstatus()" >
<div id="statuslist" style="width: 100%">

    <div class="statusitem1">
        halo 1
    </div>

</div>