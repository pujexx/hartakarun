<?php
$this->load->view('front/maps');

?>
<br>
<h1><img style="float: left; margin: 10px;" title="Dolan Dolan" src="<?php echo base_url();?>template/images/logodolan.png" alt="Dolan yoo" width="150" />Selamat Datang Di Game Dolan Yo... !!!!</h1>
<p>Game ini adalah game bagi orang yang kurang kerjaan mau jalan-jalan tapi di paksakan&nbsp;</p>
<p>untuk mengunjungi tempat yang telah di tentukan. dan setiap tempat yang di kunjungi akan mendapat pertanyaan jika berhasil akan melanjutkan ke tempat berikutnya.</p>
<p>Game ini terinspirasi dari film kartun Dora the explorer yang setiap serinya akan diberikan 3 tempat untuk mendapatkan harta karun . misalnya jika harta karun berada di bukit maka harus mengunjungi sungai , kebun bunga dan terakhir adalah bukit . Game ini hampir sama dengan film Dora the explorer tetapi lokasi yang di munjungi adalah nyata . misal harta karun berada di Malioboro maka harus mengunjungi misalkan pasar kuncen , kraton dan terakhir Malioboro untuk mendapat kan point&nbsp;</p>

<p><img style="float: right; margin: 10px;" title="android dolan yo" src="<?php echo base_url();?>template/images/android.png" alt="dolan yoo" width="150"  /></p>
<p>Device yang di butuhkan adalah handphone Android(*) dengan fasilitas GPS&nbsp;</p>
<p>Link Download : Disini&nbsp;</p>
<p>&nbsp;</p>
<p>&nbsp;</p>
<p>&nbsp;</p>
<p>&nbsp;</p>
<p>&nbsp;</p>
<p>&nbsp;</p>
<p>&nbsp;</p>
<p>&nbsp;</p>
<h1>Coming soon</h1>
<p><img style="float: left; margin: 10px;" title="Dolan Dolan" src="<?php echo base_url();?>template/images/BB.png" alt="Dolan yoo" width="150" />Bagi kamu yang BB user jangan kawatir kami akan berupaya untuk membuatkan aplikasi ini dalam bentuk BB</p>
<p>&nbsp;</p>
<p>&nbsp;</p>
<p>&nbsp;</p>
<p>&nbsp;</p>
<p>&nbsp;</p>
<p>&nbsp;</p>
<p>&nbsp;</p>
<p>&nbsp;</p>
<p>(*) Sementara baru Android&nbsp;</p>
